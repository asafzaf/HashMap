#include "OverFlowSizeCheck.hpp"

OverFlowSizeCheck::OverFlowSizeCheck(int size) {
	m_size = size;
}